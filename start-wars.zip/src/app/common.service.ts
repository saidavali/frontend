import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root',
})
export class CommonService {
  private WEB_API_PEOPLE = "https://swapi.co/api/people/"; 
  private WEB_API_PLANETS = "https://swapi.co/api/planets/";
  private logedUser :String;

  setlogedinUser(data:String){
  	this.logedUser = data;
  }
  checkLogedInUser(){
  	return  true;
  	//(this.logedUser)? true:false;
  }
  constructor(private http:HttpClient) { }
  getDetailsUsingName(serachItem:String):Observable<any>{
  	return this.http.get(this.WEB_API_PEOPLE+ "?search="+serachItem)
  	.pipe(
  		map(data =>data['results'])
  	   );
  }
  private resultData;
  searchPlanets(serachItem:String):Observable<any>{
  	return this.http.get(this.WEB_API_PLANETS + "?search="+serachItem)
  	.pipe(
  		map(data =>{
			this.resultData = data['results'];
			this.resultData.sort(function(a,b) {
			a.population = (a.population == "unknown")?0:a.population;
			b.population = (b.population == "unknown")?0:b.population;
			return  parseInt(b.population)-parseInt(a.population);
			});
			return this.resultData;
  		})
  	   );
  }

}