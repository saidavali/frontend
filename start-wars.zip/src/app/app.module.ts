import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule }    from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { RoutermoduleRoutingModule } from './routermodule/routermodule-routing.module';

import { CommonService } from './common.service';
import { CanActivateViaAuthGuard } from './CanActivateViaAuthGuard';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { SearchComponent } from './components/search/search.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,ReactiveFormsModule,RoutermoduleRoutingModule
  ],
  providers: [CommonService,CanActivateViaAuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
