import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import {Router } from '@angular/router';
import {CommonService} from './../../common.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm = new FormGroup({
    Name: new FormControl(''),
    Pwd: new FormControl(''),
  });

  constructor(private service:CommonService, private router: Router) { }

  ngOnInit() {
  }
  onSubmit(){
  	this.service.getDetailsUsingName(this.loginForm.value['Name']).subscribe((success)=>{
	  	if(success && success.length != 0){
	  		for(let i in success){
	  			if(success[i].name == this.loginForm.value['Name'] &&  success[i].birth_year == this.loginForm.value['Pwd']){
	  				console.log("login success");
	  				this.service.setlogedinUser(this.loginForm.value['Name']);
	  				this.router.navigate(['/search'])
	  			}
	  		}
	  	}
  	});
  }

}
