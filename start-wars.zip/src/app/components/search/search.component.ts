import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import {
   debounceTime, distinctUntilChanged, switchMap
 } from 'rxjs/operators';

 import {CommonService} from './../../common.service';
 import {Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  planets$: Observable<any[]>;
  private searchTerms = new Subject<string>();
  constructor(private service:CommonService, private router:Router) { }

  ngOnInit() {
   this.planets$ = this.searchTerms.pipe(
      // wait 300ms after each keystroke before considering the term
       debounceTime(300),
       // switch to new search observable each time the term changes
       switchMap((term: string) => this.service.searchPlanets(term)),
    );
  }
  logout(){
  	this.service.setlogedinUser(null);
  	this.router.navigate(['']);
  }
  search(term: string): void {
    this.searchTerms.next(term);
  }
  planetData;
  selectedPlanet(planet){
  	console.log(planet);
  	this.planetData = planet;
  	console.log(this.planets$);
  	if(planet){
  	 this.searchTerms.next();
  	}
  }
}
