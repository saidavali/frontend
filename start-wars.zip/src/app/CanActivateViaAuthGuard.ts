import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import {CommonService} from './common.service';


@Injectable({
  providedIn: 'root',
})
export class CanActivateViaAuthGuard implements CanActivate {

  constructor(private service: CommonService, private router:Router) {}   canActivate(
        route : ActivatedRouteSnapshot,
        state : RouterStateSnapshot
  ):Observable<boolean> | Promise<boolean> | boolean  {
  	console.log(this.service.checkLogedInUser());
  	if(! this.service.checkLogedInUser()){
  		this.router.navigate(['']);
  	}
    return true;
  }
}